# friendmailfb
Mendapatkan Email Teman Dan Cek Vuln/Tidak di yahoo.com
How to run? How?
